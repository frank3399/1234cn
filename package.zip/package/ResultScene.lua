require "Include"

local function checkMsPkgFinish(pkg)
    for k,ms in pairs(pkg) do
        if ms.status ~= dd.MissionStatus.Passed then return false end 
    end
    return true
end 

local function setAchv(d1,d2,d3,ln,lk,wh,lv1,lv2,lv3)
    local pk = math.pow(2,lk)
    if string.sub(d1,ln-lk,ln-lk) == '0' then
        if dd.StoreData2[wh] >= lv1 then
            dd.StoreData2[11] = dd.StoreData2[11] + pk
            return 1
        end
    elseif string.sub(d2,ln-lk,ln-lk) == '0'  then
        if dd.StoreData2[wh] >= lv2 then
            dd.StoreData2[12] = dd.StoreData2[12] + pk
            return 1
        end
    elseif string.sub(d3,ln-lk,ln-lk) == '0' then
        if dd.StoreData2[wh] >= lv3 then
            dd.StoreData2[13] = dd.StoreData2[13] + pk
            return 1
        end
    end
    return 0
end

local function setFnsh(d1,d2,d3,ln,lk)
    local pk = math.pow(2,lk)
    if string.sub(d1,ln-lk,ln-lk) == '0' then
        if checkMsPkgFinish(mm.normalMission) == true then
            dd.StoreData2[11] = dd.StoreData2[11] + pk
            return 1
        end
    elseif string.sub(d2,ln-lk,ln-lk) == '0'  then
        if checkMsPkgFinish(mm.challengeMission) == true then
            dd.StoreData2[12] = dd.StoreData2[12] + pk
            return 1
        end
    elseif string.sub(d3,ln-lk,ln-lk) == '0' then
        if checkMsPkgFinish(mm.exploreMission) == true then
            dd.StoreData2[13] = dd.StoreData2[13] + pk
            return 1
        end
    end
    return 0
end


local function deterAchievement(score)

    userDataDecode()

    dd.StoreData2[17] = dd.StoreData2[17] + score.numsAdd[4] + math.floor(score.numsAdd[3]/2) --17t 5+

    for k,v in pairs(score.ctAdd) do 
        if k > 5 then 
            dd.StoreData2[18] = dd.StoreData2[18] + score.ctAdd[k]  --18t 5up
        end 
    end 

    if dd.StoreData2[19] < score.maxCtClk then  --19t combos
        dd.StoreData2[19] = score.maxCtClk 
    end 

    dd.StoreData2[21] = dd.StoreData2[21] + score.totTb[1]  --21t fixer
    dd.StoreData2[22] = dd.StoreData2[22] + score.totTb[2]  --21t box
    dd.StoreData2[23] = dd.StoreData2[23] + score.totTb[3]  --21t combiner

    ------------------
    local d1 = f10tn(dd.StoreData2[11],2)
    local d2 = f10tn(dd.StoreData2[12],2)
    local d3 = f10tn(dd.StoreData2[13],2)
    local ln = string.len(d1)
    local cnt = 0
    cnt = cnt + setFnsh(d1,d2,d3,ln,0) -- Finsh pkg
    cnt = cnt + setAchv(d1,d2,d3,ln,1,5,20,40,60) -- lv
    cnt = cnt + setAchv(d1,d2,d3,ln,2,2,3000,8000,16000) --coin
    cnt = cnt + setAchv(d1,d2,d3,ln,3,20,6,15,30) -- share
    cnt = cnt + setAchv(d1,d2,d3,ln,4,19,30,50,80) -- combos
    cnt = cnt + setAchv(d1,d2,d3,ln,5,17,20,50,90) -- 5+
    cnt = cnt + setAchv(d1,d2,d3,ln,6,18,20,50,90) -- 5up
    cnt = cnt + setAchv(d1,d2,d3,ln,7,21,20,50,90) -- fixer
    cnt = cnt + setAchv(d1,d2,d3,ln,8,22,20,50,90) -- boxer
    cnt = cnt + setAchv(d1,d2,d3,ln,9,23,20,50,90) -- combiner

    userDataCode()
    return cnt

end



function ResultScene(score,mission,pass)
    local confirmBt
    local iswirteMs = false
    local isPopSc = false
    local bkgIm
    local shareBt
    local slb1
    local dlockMs 
    local acvCnt
    -- local lb1 
    local lb2 
    local lb3 
    local lb4 
    local lb5 
    local lb6
    local lb7
    local lb8
    local lb9
    local lb10
    local lb11 
    local lb12 
    local lb13
    local lb14 
    local lb15
    local lb16
    local lb17

    local b1
    local b2
    local b3
    local s1
    local s2
    local s3
    local l1
    local l2
    local l3
    local ss1
    local ss2
    local ss3
    
    
    local passOrNotBt
    local step 
    local maxCtAdd 
    local maxCtClk 
    local numsAdd 
    local ctAdd 
    local ctClk 
    local totTb

    local tCtAddNum = 0
    local tCtClk = 0
    local lb1v=0 
    local lb2v=0 
    local lb3v=0 
    local lb4v=0 
    local lb5v=0 
    local lb6v=0 
    local lb7v=0 
    local lb8v=0 
    local lb9v=0 
    local lb10v=0 
    local lb11v=0  
    local schedulerID = 0

    local sc=0
    local coin = 0
    local mulc = 0
    local muls = 0
    local addc = 0
    local adds = 0
    local bfsc = 0
    local bfcn = 0
    local usScore
    local self = cc.Scene:create()
    local cnt =0
    local lvUpTime =0
    local barPer ={}
    local lvBar
    local tbIndx
    local usLv
    local isSMs = false
    local isLeft = false
    local isLvUpFinished = false
    local isSharedChange = false
    local ishighsc = false
    
    local function unlock(bback,llight,ssimg,sslb)
        bback:setSelectedState(true)       
        llight:setSelectedState(true)
        ssimg:setSelectedState(true)
        
        
        local show = cc.Show :create()
        local blnk = cc.Blink:create(0.8,2)
        local seq = cc.Sequence:create(show,blnk)
        sslb:runAction(seq)
        
        local ro = cc.RotateBy:create(8,1800)
        local rero = cc.RepeatForever:create(ro)

        llight:runAction(rero)    
        
        M.playEffect(M.unlock,0.4) 
    end 

    local function addEach1(d1,d2,d3,ln,lk,lv1c,lv2c,lv3c,lv1s,lv2s,lv3s)

        if   string.sub(d3,ln-lk,ln-lk) == '1' then
            mulc = mulc + lv3c
            muls = muls + lv3s
        elseif   string.sub(d2,ln-lk,ln-lk) == '1' then 
            mulc = mulc + lv2c
            muls = muls + lv2s
        elseif string.sub(d1,ln-lk,ln-lk) == '1' then 
            mulc = mulc + lv1c
            muls = muls + lv1s
        end 
    end

    local function addEach2(d1,d2,d3,ln,lk,lv1c,lv2c,lv3c,lv1s,lv2s,lv3s,mul)

        if   string.sub(d3,ln-lk,ln-lk) == '1' then
            adds =  adds + lv3s*mul
            addc =  addc + lv3c*mul
        elseif   string.sub(d2,ln-lk,ln-lk) == '1' then 
            adds =  adds + lv2s*mul
            addc =  addc + lv2c*mul        
        elseif string.sub(d1,ln-lk,ln-lk) == '1' then 
            adds =  adds + lv1s*mul
            addc =  addc + lv1c*mul
        end   
    end

    local function addEach3(d1,d2,d3,ln,lk,lv1c,lv2c,lv3c,lv1s,lv2s,lv3s,mul)

        if   string.sub(d3,ln-lk,ln-lk) == '1' then
            return lv3s*mul,lv3c*mul
        elseif   string.sub(d2,ln-lk,ln-lk) == '1' then
            return lv2s*mul,lv2c*mul
        elseif string.sub(d1,ln-lk,ln-lk) == '1' then
            return lv1s*mul,lv1c*mul
        end
    end

    local function addScoreAndCoin()
        dd.StoreData2[5] = decode5(dd.StoreData2[5]) --lv
        dd.StoreData2[9] = decode9(dd.StoreData2[9],9)

        dd.StoreData2[10] = decode9(dd.StoreData2[10],10)  
        dd.StoreData2[14] = decode9(dd.StoreData2[14],14)
        dd.StoreData2[15] = decode9(dd.StoreData2[15],15)
        dd.StoreData2[16] = decode9(dd.StoreData2[16],16)
        local d0 = f10tn(dd.StoreData2[10],2)
        local d1 = f10tn(dd.StoreData2[14],2)
        local d2 = f10tn(dd.StoreData2[15],2)
        local d3 = f10tn(dd.StoreData2[16],2)
        local ln = string.len(d1)  

        if string.sub(d0,ln,ln)== '1' then
            addc = addc + 20
        end

        if string.sub(d0,ln-6,ln-6)== '1' then
            mulc = mulc + 30
            muls = muls + 30
        end

        addEach1(d1,d2,d3,ln,0,3,6,10,3,6,10)-- finish

        addEach1(d1,d2,d3,ln,1,0,0,0,4,8,15)-- lv

        addEach1(d1,d2,d3,ln,2,4,8,12,0,0,0)----coin

        if  gg.msShared == true then
            addEach2(d1,d2,d3,ln,3,30,50,80,60,90,120,1)-- share
        end

        local mull = 0
        for k,v in pairs(ctClk) do
            if k > 9 then
                mull = mull + math.floor(k/5)/2*ctClk[k]
            end            
        end
        addEach2(d1,d2,d3,ln,4,10,15,20,10,20,35,mull)--combos

        
        mull = numsAdd[4] + math.ceil(numsAdd[3]/2)
        addEach2(d1,d2,d3,ln,5,10,15,20,10,20,35,mull)-- 5+

        mull = 0
        for k,v in pairs(ctAdd) do 
            if k > 5 then
                mull =mull + k/5*ctAdd[k]
            end
        end
        addEach2(d1,d2,d3,ln,6,10,15,20,10,20,35,mull)--18t 5up

        mull = totTb[1]
        addEach2(d1,d2,d3,ln,7,5,10,15,8,16,25,mull)-- fixer  

        mull = totTb[2]
        addEach2(d1,d2,d3,ln,8,5,10,15,8,16,25,mull)-- boxer 

        mull = totTb[3]
        addEach2(d1,d2,d3,ln,9,5,10,15,8,16,25,mull)-- combiner 

        mulc = mulc + math.floor((dd.StoreData2[5]+1)/2) --lv
        muls = muls + math.floor(dd.StoreData2[5]/2)
        mulc = mulc + dd.StoreData2[9]  --gfinger

        sc = math.floor(bfsc*(100.0+muls)/100 +adds)
        coin = math.floor(bfcn*(100.0+mulc)/100 +addc)

        lb14:setString(tostring(muls))
        lb15:setString(tostring(mulc))  

        lb16:setString(tostring(adds))
        lb17:setString(tostring(addc))

        dd.StoreData2[9] = encode9(dd.StoreData2[9],9) 
        dd.StoreData2[5] = encode5(dd.StoreData2[5])        
        dd.StoreData2[10] = encode9(dd.StoreData2[10],10)
        dd.StoreData2[14] = encode9(dd.StoreData2[14],14)
        dd.StoreData2[15] = encode9(dd.StoreData2[15],15)
        dd.StoreData2[16] = encode9(dd.StoreData2[16],16)

    end    
    
    local function comScore1()
        if cnt < 65535 then
            cnt  = cnt+1
        end

        if isLvUpFinished == false then
            lb1v = rand4(lb1v, numsAdd[1])
            lb2v = rand4(lb2v, numsAdd[2])
            lb3v = rand4(lb3v, numsAdd[3])
            lb4v = rand4(lb4v, numsAdd[4])
            lb5v = rand4(lb5v, tCtClk)
            lb6v = rand4(lb6v, maxCtClk)
            lb7v = rand4(lb7v, tCtAddNum)
            lb8v = rand4(lb8v, maxCtAdd)
            lb9v = rand4(lb9v, step)
            lb10v = rand4(lb10v, sc)
            lb11v = rand4(lb11v, coin)

            --lb1:setString(tostring(lb1v))
            lb2:setString(tostring(lb2v))
            lb3:setString(tostring(lb3v))
            lb4:setString(tostring(lb4v))
            lb5:setString(tostring(lb5v))
            lb6:setString(tostring(lb6v))
            lb7:setString(tostring(lb7v))
            lb8:setString(tostring(lb8v))
            lb9:setString(tostring(lb9v))           
            lb10:setString(tostring(lb10v))
            lb11:setString(tostring(lb11v))

            if barPer[1] < barPer[3] or lvUpTime >0 then 
                barPer[1] = barPer[1] + 2
                if barPer[1] >= 100 and lvUpTime >0 then 
                    M.playEffect(M.levelUp,1)
                    lvUpTime = lvUpTime -1                    
                    barPer[1] = 0
                    tbIndx = tbIndx + 1
                    usLv = usLv + 1 
                    lb12:setString('L'..usLv)
                    local scaleby = cc.ScaleBy:create(0.2, 1.3)
                    local actionbyback = scaleby:reverse()           
                    local seq= cc.Sequence:create(scaleby,actionbyback)
                    lb12:runAction(seq)
                end 
                lvBar:setPercent(barPer[1])
                local lvsc = math.floor(usScore[tbIndx] * barPer[1]/100)
                lb13:setString(lvsc.."/"..usScore[tbIndx])
            end           

            if barPer[1] >= barPer[3] and lvUpTime == 0 then 
                lvBar:setPercent(barPer[3])
                lb13:setString(usScore[2].."/"..usScore[tbIndx])        
            end   

        end 
    end

    local function comScore()
        
        comScore1()
        
        if isSharedChange == false and gg.msShared ==true then 
            isSharedChange = true
            isLvUpFinished = false
            userDataDecode()
            ------------------
            local d1 = f10tn(dd.StoreData2[11],2)
            local d2 = f10tn(dd.StoreData2[12],2)
            local d3 = f10tn(dd.StoreData2[13],2)
            local d4 = f10tn(dd.StoreData2[14],2)
            local d5 = f10tn(dd.StoreData2[15],2)
            local d6 = f10tn(dd.StoreData2[16],2)
            local ln = string.len(d1)

            if mission.isShared  == 0  and pass == true then
                mission.isShared = 1
                dd.StoreData2[20] = dd.StoreData2[20] + 1
            end     

            local bs = sc  --before  score
            local bc = coin
            mulc = 0
            muls = 0
            addc = 0
            adds = 0           
            userDataCode()
            addScoreAndCoin()
            userDataDecode()

            dd.StoreData2[1] = dd.StoreData2[1] + coin - bc
            dd.StoreData2[2] = dd.StoreData2[2] + coin - bc
            
            if dd.StoreData2[2] >999999 then
            	dd.StoreData2[2] = 999999
            end
            
            if dd.StoreData2[1] >999999 then
                dd.StoreData2[1] = 999999
            end


            if dd.StoreData2[5] < 60 then
                dd.StoreData2[4] = dd.StoreData2[4] + sc -bc
            else
                dd.StoreData2[4] = usScore[3]
            end 

            while dd.StoreData2[4] > usScore[tbIndx] and dd.StoreData2[5]<60 do
                dd.StoreData2[4] = dd.StoreData2[4] - usScore[tbIndx]
                dd.StoreData2[5] = dd.StoreData2[5] + 1
                lvUpTime = lvUpTime + 1
                local tlvsc = levelUpSc(dd.StoreData2[5])
                table.insert(usScore,tlvsc)
                tbIndx = tbIndx +1
            end 

            usScore[2] = dd.StoreData2[4]
            barPer[3] = math.floor(dd.StoreData2[4] *100/ usScore[tbIndx] )

            local ct = 0
            ct = ct + setAchv(d1,d2,d3,ln,1,5,20,40,60) -- lv
            ct = ct + setAchv(d1,d2,d3,ln,2,2,3000,8000,16000) --coin
            ct = ct + setAchv(d1,d2,d3,ln,3,20,6,15,30)
            local lvv = dd.StoreData2[5]
            userDataCode()

            local dms = suriveModeDelockCheck(lvv)

            if ss3:isVisible() == true then dms=1 end
            if ss2:isVisible() == true then ct=1 end

            if ct > 0 and dms ~= nil then
                unlock(b2,l2,s2,ss2)
                unlock(b3,l3,s3,ss3)
                dms = nil 
                ct = 0               
            elseif ct > 0 then
                unlock(b2,l2,s2,ss2)
                ct = 0
            elseif dms ~=nil then               
                unlock(b3,l3,s3,ss3)
                dms = nil                 
            end

            cnt = 100

            table.insert(dd.coTb, {coroutine.create(storeMsAndUData),false,false,false})
        end
        
        
        if lb1v == numsAdd[1] and lb2v==numsAdd[2] and lb3v == numsAdd[3] and lb4v == numsAdd[4]
            and lb5v == tCtClk and lb6v == maxCtClk and lb7v == tCtAddNum and lb8v== maxCtAdd
            and lb9v == step and lb10v == sc and lb11v == coin and lvUpTime == 0  and barPer[1] >= barPer[3] then

            if cnt > 20 then
                if isLvUpFinished == false then
                    isLvUpFinished = true
                    confirmBt:setVisible(true)  
                    shareBt:setVisible(true)
                    M.playEffect(M.golds)
                end
            end
            if cnt > 15  then
                if pass == true and ishighsc == true and b1:isSelected() == false then
                    unlock(b1,l1,s1,ss1)
                end

                if acvCnt > 0 and dlockMs ~= nil then                 
                    unlock(b2,l2,s2,ss2)
                    unlock(b3,l3,s3,ss3)
                    dlockMs = nil 
                    acvCnt = 0
                elseif acvCnt > 0 then
                    unlock(b2,l2,s2,ss2)    
                    acvCnt = 0        
                elseif dlockMs ~=nil then
                    unlock(b3,l3,s3,ss3)
                    dlockMs = nil 
                end
            end           
        end  
    end

    local function confirmBtCallback(sender,eventType)        
        if eventType == ccui.TouchEventType.ended  and isLeft == false and dd.sc == dd.Scn.ResultSc then
            isLeft = true   
            gg.msShared = false

            M.playEffect(M.click7,1)
            M.playMusic(M.MusicUI)
            M.playEffect(M.result,0.5) 
            confirmBt:setEnabled(false) 
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(schedulerID)
            schedulerID = 0 
            if dd.Right == true then
                showInstl()
                dd.isstore = true
                dd.StoreData2[1] = decode1(dd.StoreData2[1])
                
                DCCardsGame.gain(mission.mId, 'play', 'coin', coin, dd.StoreData2[1])
                DCCardsGame.gain(mission.mId, 'play', 'score', sc, sc)
                DCCoin.gain(mission.mId,'score',sc,sc)
                DCCoin.gain(mission.mId,'coin',coin,dd.StoreData2[1])
                dd.StoreData2[1] = encode1(dd.StoreData2[1])
            end



            local msPkg
            if  gg.m == 0 then
                msPkg = mm.collectMission
            elseif gg.m == 1 then 
                msPkg = mm.normalMission
            elseif gg.m == 2 then 
                msPkg = mm.challengeMission
            elseif gg.m == 3 then 
                msPkg = mm.exploreMission
            elseif gg.m == 4 then 
                msPkg = mm.survivalMission           
            end 
            local sce = RoomScene(msPkg)
            cc.Director:getInstance():replaceScene(sce)  
        end
    end

    local function shareBtCallback(sender,eventType)        
        if  isLeft == false and dd.sc == dd.Scn.ResultSc then
            M.playEffect(M.click,1) 
            if eventType == ccui.TouchEventType.ended  then 
                local sstr = {}
                sstr.name = '['..mission.mId..']'
                sstr.score = sc      
                sstr.pass = pass                      
                onCaptured(sstr) 
            end 

        end
    end

    local function bkgImCallback(sender,eventType)   
        if eventType == ccui.TouchEventType.ended then 
            bkgIm:setTouchEnabled(false)
            lb1v = numsAdd[1]
            lb2v = numsAdd[2]
            lb3v = numsAdd[3]
            lb4v = numsAdd[4]
            lb5v = tCtClk
            lb6v = maxCtClk
            lb7v = tCtAddNum
            lb8v = maxCtAdd
            lb9v = step
            lb10v = sc
            lb11v = coin
        end
    end 
    local function  init2(ccsLayout,scx,scy)

        lb2 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb3 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb4 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb5 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb6 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb7 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb8 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb9 = cc.LabelBMFont:create("0","fnumber2.fnt")
        lb10 = cc.LabelBMFont:create("0","fnumber3.fnt")
        lb11 = cc.LabelBMFont:create("0","fnumber5.fnt")
        lb12 = cc.LabelBMFont:create("0","myChar.fnt")
        slb1 = cc.LabelBMFont:create("a","myChar.fnt") 
        
        lb13 = ccsLayout:getChildByName("lb13")
        lb14 = ccsLayout:getChildByName("lb14")
        lb15 = ccsLayout:getChildByName("lb15")
        lb16 = ccsLayout:getChildByName("lb16")
        lb17 = ccsLayout:getChildByName("lb17")
        
        lb2:setAnchorPoint(cc.p(0.5,0.5))
        lb3:setAnchorPoint(cc.p(0.5,0.5))
        lb4:setAnchorPoint(cc.p(0.5,0.5))
        lb9:setAnchorPoint(cc.p(0.5,0.5))
        
        lb5:setAnchorPoint(cc.p(0,0.5))
        lb6:setAnchorPoint(cc.p(0,0.5))
        
        lb7:setAnchorPoint(cc.p(0,0.5))
        lb8:setAnchorPoint(cc.p(0,0.5))
        
        lb10:setAnchorPoint(cc.p(0.5,0.5))
        lb11:setAnchorPoint(cc.p(0.5,0.5))
        
        lb12:setAnchorPoint(cc.p(0.5,0.5))
        slb1:setAnchorPoint(cc.p(0,0.5)) 
        
        lb9:setPosition(cc.p(128,595))
        lb2:setPosition(cc.p(250,595))
        lb3:setPosition(cc.p(378,595))
        lb4:setPosition(cc.p(503,595))
        
        lb5:setPosition(cc.p(155,478))
        lb6:setPosition(cc.p(400,478))
        
        lb7:setPosition(cc.p(155,364))
        lb8:setPosition(cc.p(400,364))
        
        lb10:setPosition(cc.p(144,206))
        
        lb11:setPosition(cc.p(480,741))
        
        lb12:setPosition(cc.p(261,190))
        slb1:setPosition(cc.p(80,797))   
        
        lb11:setScale(0.9)
        lb12:setScale(0.8)
        
        ccsLayout:addChild(lb2,3,3)  
        ccsLayout:addChild(lb3,3,3) 
        ccsLayout:addChild(lb4,3,3)  
        ccsLayout:addChild(lb5,3,3) 
        ccsLayout:addChild(lb6,3,3)  
        ccsLayout:addChild(lb7,3,3) 
        ccsLayout:addChild(lb8,3,3)  
        ccsLayout:addChild(lb9,3,3) 
        ccsLayout:addChild(lb10,3,3)  
        ccsLayout:addChild(lb11,3,3) 
        ccsLayout:addChild(lb12,3,3)
        ccsLayout:addChild(slb1,3,3)
        
        lb2:setString('0')
        lb3:setString('0')
        lb4:setString('0')
        lb5:setString('0')
        lb6:setString('0')
        lb7:setString('0')
        lb8:setString('0')
        lb9:setString('0')
        lb10:setString('0')
        lb11:setString('0')
        lb13:setString('0')
        lb14:setString('0')
        lb15:setString('0')
        lb16:setString('0')
        lb17:setString('0')       
        
        b1 = ccsLayout:getChildByName("b1")
        b2 = ccsLayout:getChildByName("b2")
        b3 = ccsLayout:getChildByName("b3")
 
        s1 = ccsLayout:getChildByName("s1")
        s2 = ccsLayout:getChildByName("s2")
        s3 = ccsLayout:getChildByName("s3")
        
        l1 = ccsLayout:getChildByName("l1")
        l2 = ccsLayout:getChildByName("l2")
        l3 = ccsLayout:getChildByName("l3")

        ss1 = ccsLayout:getChildByName("ss1")
        ss2 = ccsLayout:getChildByName("ss2")
        ss3 = ccsLayout:getChildByName("ss3")    
        
        b1:setSelectedState(false)   
        b2:setSelectedState(false)   
        b3:setSelectedState(false)   
        
        b1:setTouchEnabled(false)
        b2:setTouchEnabled(false)
        b3:setTouchEnabled(false)
        
        s1:setSelectedState(false)   
        s2:setSelectedState(false)   
        s3:setSelectedState(false) 
        
        s1:setTouchEnabled(false)
        s2:setTouchEnabled(false)
        s3:setTouchEnabled(false)
        
        l1:setSelectedState(false)   
        l2:setSelectedState(false)   
        l3:setSelectedState(false) 
        
        l1:setTouchEnabled(false)
        l2:setTouchEnabled(false)
        l3:setTouchEnabled(false)
        
        ss1:setString("关卡新记录")
        ss2:setString("新成就解锁")
        ss3:setString("新生存模式\n关卡解锁")
        
        ss1:setVisible(false)
        ss2:setVisible(false)
        ss3:setVisible(false)
        
        
    end
    

    local function init()

        dd.sc = dd.Scn.ResultSc         
        local ccsLayout = ccs.GUIReader:getInstance():widgetFromJsonFile("ResultUI_1.json") 

        self:addChild(ccsLayout)       
        bkgIm = ccsLayout:getChildByName("bkgIm")
        bkgIm:addTouchEventListener(bkgImCallback)
        bkgIm:setTouchEnabled(true)

        local sz = bkgIm:getContentSize()
        local scx = dd.DesignSize.Width/sz.width
        local scy = dd.DesignSize.Height/sz.height


        confirmBt = ccsLayout:getChildByName("confirmBt")
        confirmBt:addTouchEventListener(confirmBtCallback)
        confirmBt:setVisible(false)

        shareBt = ccsLayout:getChildByName("shareBt")
        shareBt:addTouchEventListener(shareBtCallback)
        shareBt:setVisible(false)
        init2(ccsLayout,scx,scy)
        
        passOrNotBt = ccsLayout:getChildByName("passOrNotBt")       
        passOrNotBt:setTouchEnabled(false)


        lvBar= ccsLayout:getChildByName("lvBar")       
        -------------------       
        score.step = gameDataDecode(score.step)
        score.score = gameDataDecode(score.score)
        score.maxCtAdd = gameDataDecode(score.maxCtAdd)
        score.maxCtClk = gameDataDecode(score.maxCtClk)
        score.numsAdd = gameDataDecode(score.numsAdd)
        score.ctAdd = gameDataDecode(score.ctAdd)
        score.ctClk =gameDataDecode(score.ctClk)

        step = score.step 
        maxCtAdd = score.maxCtAdd 
        maxCtClk = score.maxCtClk
        numsAdd = score.numsAdd 
        ctAdd = score.ctAdd 
        ctClk = score.ctClk 
        totTb = score.totTb

        local str = ''
        local str1 = string.sub(mission.mId,1,1)
        local str2 = string.sub(mission.mId,2,2)
        local str3 = string.sub(mission.mId,4)

        local mstr
        

        if str1 == 'N' then
            mstr = 'a'            
        elseif str1 == 'C' then
            mstr = 'b'   
        elseif str1 == 'E' then
            mstr = 'c'   
        elseif str1 == 'S' then
            mstr = 'd'   
        end 

        if str2 == '1' then
            mstr= mstr..'A'..str3
        elseif str2 == '2' then
            mstr= mstr..'B'..str3
        elseif str2 == '3' then
            mstr= mstr..'C'..str3
        elseif str2 == '4' then
            mstr= mstr..'D'..str3
        end 
        slb1:setString(mstr)
            
       
        sc = sc + score.numsAdd[1] * 1.5
        sc = sc + score.numsAdd[2] * 3.5
        sc = sc + score.numsAdd[3] * 8
        sc = sc + score.numsAdd[4] * 16
        coin = coin + score.numsAdd[1] * 0.5
        coin = coin + score.numsAdd[2] * 1.5
        coin = coin + score.numsAdd[3] * 3
        coin = coin + score.numsAdd[4] * 6

        ctAdd[1]=0
        for k,v in pairs(ctAdd) do
            tCtAddNum = tCtAddNum + v
            if k <6 then 
                sc = sc + math.pow(2, k)*v 
                if v > 3 then   coin = coin + v end   
            else
                sc = sc + math.pow(2, 6)*v + 2*k*v
                if v > 3 then   coin = coin + 6+ (v-6)*0.8 end   
            end 
        end

        coin = coin + score.maxCtAdd
        sc = sc + score.maxCtAdd * 2
        ctClk[1]=0
        for k,v in pairs(ctClk) do
            tCtClk = tCtClk + v
            if v > 2 then  sc = sc + k*v end            
            if v > 4 then   coin = coin + v/2.5 end
        end

        coin = coin + score.maxCtClk /2
        sc = sc + score.maxCtClk * 2
        bfsc = sc
        bfcn = coin
        ----------------
        addScoreAndCoin()
        ----------------              
        iswirteMs = true
        --print('-------1-------',mission.id)
        msDataDecode(mission)

        ishighsc = false
       -- print(mission.id,mission.status)

        if mission.score == nil or mission.score < sc or mission.score == 0 then 
            ishighsc = true              
        end 

        coin = coin - mission.pay.Cost
        if coin < 1 then coin = 1 end

        if(string.sub(mission.mId, 1, 1)=='S' ) then  
            if ishighsc ==  true then                  
                pass = true                
            else
                pass = false
            end              
        end

        if pass == true then             
            if mission.status == dd.MissionStatus.Unpass  then 
                dd.passMsCnt =  dd.passMsCnt+1
            end 
            mission.status = dd.MissionStatus.Passed 
            passOrNotBt:setSelectedState(true)
            missionUnlock(mission)
            if ishighsc == true then                
                mission.score = sc + 39  
                mission.score = math.floor(mission.score) 
                if  mission.coin ~= nil  then 
                    coin = coin + mission.coin   
                    dd.msCg = true
                end
            end             
        else
            passOrNotBt:setSelectedState(false)
        end         
        if gg.msShared == true   then            
            isSharedChange = true
            if mission.isShared  == 0  and pass == true then 
                mission.isShared = 1 
                dd.StoreData2[20] = decode9(dd.StoreData2[20],20) 
                dd.StoreData2[20] = dd.StoreData2[20] + 1
                dd.StoreData2[20] = encode9(dd.StoreData2[20],20)                 
            end    
        end 
      --  print('-------2-------',mission.id,mission.status,mission.coin) 
        msDataCode(mission)   
      --  print('-------3-------',mission.id)
        coin = math.floor(coin) 
        sc = math.floor(sc)         

        dd.StoreData2[1] = decode1(dd.StoreData2[1]) 
        dd.StoreData2[2] = decode2(dd.StoreData2[2]) 

        dd.StoreData2[1] = dd.StoreData2[1] + coin    
        dd.StoreData2[2] = dd.StoreData2[2] + coin  


        dd.StoreData2[2] = encode2(dd.StoreData2[2]) 
        dd.StoreData2[1] = encode1(dd.StoreData2[1]) 

        dd.StoreData2[3] = decode3(dd.StoreData2[3])  --3 TotalStep = 
        dd.StoreData2[3] = dd.StoreData2[3] + step
        if dd.StoreData2[3] >999999 then
            dd.StoreData2[3] = 999999
        end
        dd.StoreData2[3] = encode3(dd.StoreData2[3])  

        dd.StoreData2[4] = decode4(dd.StoreData2[4])  --4 Score =
        dd.StoreData2[5] = decode5(dd.StoreData2[5])  --5 Level =   

        usScore = {}
        usScore[1] = dd.StoreData2[4]   
        usScore[3] = levelUpSc(dd.StoreData2[5])

        barPer[1] = math.floor(dd.StoreData2[4] *100/ usScore[3] )
        barPer[2] = barPer[1] 


        if dd.StoreData2[5] < 60 then     
            dd.StoreData2[4] = dd.StoreData2[4] + sc             
        else
            dd.StoreData2[4] = usScore[3]
        end

        tbIndx = 3
        usLv = dd.StoreData2[5]
        lb12:setString('L'..usLv)
        usScore[2] = 0
        while dd.StoreData2[4] > usScore[tbIndx] and dd.StoreData2[5]<60 do
            dd.StoreData2[4] = dd.StoreData2[4] - usScore[tbIndx]
            dd.StoreData2[5] = dd.StoreData2[5] + 1
            lvUpTime = lvUpTime + 1
            local tlvsc = levelUpSc(dd.StoreData2[5])
            table.insert(usScore,tlvsc)
            tbIndx = tbIndx +1
        end
        --if dd.StoreData2[5] > 1 then dd.Right = false end
        usScore[2] = dd.StoreData2[4]
        barPer[3] = math.floor(dd.StoreData2[4] *100/ usScore[tbIndx] )
        tbIndx = 3
        lvBar:setPercent(barPer[1])
        lb13:setString(usScore[1].."/"..usScore[3])

        DCAccount.setLevel(dd.StoreData2[5])

        dlockMs = suriveModeDelockCheck(dd.StoreData2[5])  
        dd.StoreData2[4] = encode4(dd.StoreData2[4])  
        dd.StoreData2[5] = encode5(dd.StoreData2[5])  
        acvCnt = deterAchievement(score) 
        table.insert(dd.coTb, {coroutine.create(storeMsAndUData),iswirteMs,false,false})
       
        ---------review app
        local rev = cc.UserDefault:getInstance():getStringForKey('review') 

        if pass == true  and  dd.passMsCnt > 0 and ( (dd.passMsCnt % 10 == 0 and rev~='OK')  or (dd.passMsCnt% 40  == 0 )) then
            dd.needReview = true   
        else
            dd.needReview = false   
        end
        
       -- playcount = playcount +1
      --  cc.UserDefault:getInstance():setIntegerForKey('playCount',playcount)
        cc.UserDefault:getInstance():flush()

        if schedulerID == 0 then
            schedulerID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(comScore, 0, false) 
        end

    end

    init()
    return self
end

